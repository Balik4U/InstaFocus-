package com.instafocus

import android.content.Context
import java.time.LocalDate

enum class Mode { NONE, MESSAGES, REEL, PROFILE }

/** All data stays in local SharedPreferences. Only durations are stored, never content. */
class Store(c: Context) {
    private val p = c.applicationContext.getSharedPreferences("instafocus", 0)
    private fun day(offset: Long = 0) = LocalDate.now().minusDays(offset).toString()

    var blockReels: Boolean get() = p.getBoolean("br", true); set(v) { p.edit().putBoolean("br", v).apply() }
    var blockExplore: Boolean get() = p.getBoolean("be", true); set(v) { p.edit().putBoolean("be", v).apply() }
    var messageOnly: Boolean get() = p.getBoolean("mo", false); set(v) { p.edit().putBoolean("mo", v).apply() }
    var askPurpose: Boolean get() = p.getBoolean("ap", true); set(v) { p.edit().putBoolean("ap", v).apply() }
    var limitMin: Int get() = p.getInt("lim", 0); set(v) { p.edit().putInt("lim", v).apply() } // 0 = off
    var bypassUntil: Long get() = p.getLong("byp", 0); set(v) { p.edit().putLong("byp", v).apply() }
    var mode: Mode get() = Mode.valueOf(p.getString("mode", "NONE")!!); set(v) { p.edit().putString("mode", v.name).apply() }

    val effectiveMode get() = if (messageOnly) Mode.MESSAGES else mode
    fun bypassOn() = System.currentTimeMillis() < bypassUntil
    fun bypassFor(min: Int) { bypassUntil = System.currentTimeMillis() + min * 60_000L }

    fun usageMs(offset: Long = 0) = p.getLong("u_" + day(offset), 0)
    fun addUsage(ms: Long) { p.edit().putLong("u_" + day(), usageMs() + ms).apply() }
    fun limitHit() = limitMin > 0 && usageMs() >= limitMin * 60_000L
    fun warned() = p.getBoolean("w_" + day(), false)
    fun setWarned() { p.edit().putBoolean("w_" + day(), true).apply() }
}
