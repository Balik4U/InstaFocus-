package com.instafocus

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private fun ComponentActivity.openIg(uri: String) {
    runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage("com.instagram.android")) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = Store(this)
        setContent { MaterialTheme { App(s) } }
    }
    private fun a11yOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains("$packageName/") == true

    @Composable fun App(s: Store) {
        var tab by remember { mutableIntStateOf(0) }
        var on by remember { mutableStateOf(a11yOn()) }
        LaunchedEffect(tab) { on = a11yOn() }
        Scaffold(bottomBar = {
            NavigationBar { listOf("Dashboard", "Controls", "Privacy").forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) }) } }
        }) { pad ->
            Column(Modifier.padding(pad).padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("InstaFocus", style = MaterialTheme.typography.headlineMedium)
                when (tab) { 0 -> Dashboard(s, on); 1 -> Controls(s); else -> Privacy() }
            }
        }
    }

    @Composable fun Dashboard(s: Store, on: Boolean) {
        var byp by remember { mutableStateOf(s.bypassOn()) }
        if (!on) Card { Column(Modifier.padding(16.dp)) {
            Text("Setup needed", style = MaterialTheme.typography.titleMedium)
            Text("InstaFocus uses Android's Accessibility Service to see which Instagram section is open (Reels, Explore, Messages). It does not read messages, profile content or passwords, and nothing leaves your phone.")
            Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Open Accessibility settings") }
        } }
        val used = (s.usageMs() / 60000).toInt(); val lim = s.limitMin
        Card { Column(Modifier.padding(16.dp)) {
            Text("Instagram today", style = MaterialTheme.typography.titleMedium)
            Text("$used min" + if (lim > 0) " of $lim" else "", style = MaterialTheme.typography.headlineSmall)
            if (lim > 0) LinearProgressIndicator(progress = { (used / lim.toFloat()).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
        } }
        Card { Column(Modifier.padding(16.dp)) {
            Text("Last 7 days (min)", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                val d = (6L downTo 0L).map { (s.usageMs(it) / 60000).toInt() }; val mx = maxOf(d.max(), 1)
                d.forEach { v -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.width(22.dp).height((60 * v / mx + 2).dp).background(MaterialTheme.colorScheme.primary)); Text("$v", style = MaterialTheme.typography.labelSmall) } }
            }
        } }
        Card { Column(Modifier.padding(16.dp)) {
            Text("Temporary bypass", style = MaterialTheme.typography.titleMedium)
            Text(if (byp) "Blocking paused" else "Pause all blocking when you really need it.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { s.bypassFor(10); byp = true }) { Text("10 min") }
                OutlinedButton(onClick = { s.bypassFor(30); byp = true }) { Text("30 min") }
                if (byp) TextButton(onClick = { s.bypassUntil = 0; byp = false }) { Text("End") }
            }
        } }
        OutlinedButton(onClick = { openIg("instagram://direct_inbox") }) { Text("Open Instagram messages") }
    }

    @Composable fun Controls(s: Store) {
        var br by remember { mutableStateOf(s.blockReels) }; var be by remember { mutableStateOf(s.blockExplore) }
        var mo by remember { mutableStateOf(s.messageOnly) }; var ap by remember { mutableStateOf(s.askPurpose) }
        var lim by remember { mutableFloatStateOf(s.limitMin.toFloat()) }
        @Composable fun Row2(t: String, sub: String, v: Boolean, f: (Boolean) -> Unit) =
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(t); Text(sub, style = MaterialTheme.typography.bodySmall) }
                Switch(checked = v, onCheckedChange = f) }
        Row2("Block Reels feed", "Reels sent in chats still open, but can't be swiped", br) { br = it; s.blockReels = it }
        Row2("Block Explore", "Stops recommendation scrolling", be) { be = it; s.blockExplore = it }
        Row2("Message-only mode", "Only chats are available", mo) { mo = it; s.messageOnly = it }
        Row2("Ask my purpose", "Prompt each time you open Instagram", ap) { ap = it; s.askPurpose = it }
        Text(if (lim < 5) "Daily limit: off" else "Daily limit: ${lim.toInt()} min")
        Slider(value = lim, onValueChange = { lim = (it / 5).toInt() * 5f; s.limitMin = if (lim < 5) 0 else lim.toInt() }, valueRange = 0f..180f)
        Text("You get a warning at 90%. After the limit only messaging stays available.", style = MaterialTheme.typography.bodySmall)
        var profile by remember { mutableStateOf("") }
        OutlinedTextField(profile, { profile = it.trim().removePrefix("@") }, label = { Text("Open a profile (username)") }, singleLine = true)
        Button(enabled = profile.isNotBlank(), onClick = { s.mode = Mode.PROFILE; openIg("instagram://user?username=$profile") }) { Text("Open profile") }
    }

    @Composable fun Privacy() {
        Text("Privacy", style = MaterialTheme.typography.titleMedium)
        Text("• Everything is processed on your device. InstaFocus has no internet permission.\n" +
            "• The Accessibility Service only checks which Instagram screen is showing (by element ID). It never reads message text, usernames, or passwords.\n" +
            "• Only daily usage minutes and your settings are stored, locally.\n" +
            "• If Instagram changes its layout and a screen can't be recognised, InstaFocus does nothing rather than blocking you.\n" +
            "• You can disable it at any time in Android Settings > Accessibility, or use the temporary bypass.\n" +
            "• Not affiliated with Instagram or Meta.")
    }
}

class PurposeActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); val s = Store(this)
        fun pick(m: Mode) { s.mode = m; finish() }
        setContent { MaterialTheme { Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("What are you opening Instagram for?", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(20.dp))
            listOf("Messages" to Mode.MESSAGES, "View a Reel someone sent me" to Mode.REEL, "Check a specific profile" to Mode.PROFILE, "Just browsing" to Mode.NONE).forEach { (t, m) ->
                Button(onClick = { pick(m) }, Modifier.fillMaxWidth().padding(4.dp)) { Text(t) } }
            TextButton(onClick = { moveTaskToBack(true); finish() }) { Text("Never mind") }
        } } }
    }
}

class BlockActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); val s = Store(this)
        setContent { MaterialTheme { Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text(if (s.limitHit()) "Daily limit reached — only messages are available." else "Reels feed blocked — you came here to message someone.", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(20.dp))
            Button(onClick = { openIg("instagram://direct_inbox"); finish() }) { Text("Go to messages") }
            TextButton(onClick = { s.bypassFor(10); finish() }) { Text("Bypass for 10 min") }
            TextButton(onClick = { finish() }) { Text("Close") }
        } } }
    }
}
