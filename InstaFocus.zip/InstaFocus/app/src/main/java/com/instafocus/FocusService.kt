package com.instafocus

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Detects WHICH Instagram screen is open via view IDs only. Never reads text content.
 * IDs live in one place (below) so they are easy to update when Instagram changes its UI.
 * If nothing matches (UI changed), the service fails open and does nothing.
 */
class FocusService : AccessibilityService() {
    private enum class Sec { HOME, REELS, EXPLORE, DM, PROFILE, OTHER }

    private val ig = "com.instagram.android"
    private val dmIds = listOf("row_thread_composer_edittext", "direct_thread", "inbox_refreshable_thread_list_recyclerview")
    private val reelIds = listOf("clips_viewer_view_pager", "clips_tab")   // tab counts only when selected
    private val tabIds = mapOf(Sec.EXPLORE to "search_tab", Sec.PROFILE to "profile_tab", Sec.HOME to "feed_tab")

    private lateinit var s: Store
    private var lastTick = 0L; private var lastSeen = 0L; private var lastAct = 0L
    private var last = Sec.OTHER; private var fromDm = false

    override fun onServiceConnected() { s = Store(this) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!::s.isInitialized) s = Store(this)
        val now = System.currentTimeMillis()

        // Intentional-use prompt when (re)entering Instagram after 2+ min away
        if (now - lastSeen > 120_000) {
            lastSeen = now; lastTick = 0; fromDm = false
            if (s.askPurpose && !s.bypassOn()) { show(PurposeActivity::class.java); return }
        }
        lastSeen = now
        if (lastTick > 0) s.addUsage(minOf(now - lastTick, 5000)); lastTick = now  // approx. foreground time

        val lim = s.limitMin * 60_000L
        if (lim > 0 && s.usageMs() >= lim * 0.9 && !s.limitHit() && !s.warned()) {
            s.setWarned(); Toast.makeText(this, "InstaFocus: 90% of today's Instagram limit used", Toast.LENGTH_LONG).show()
        }
        if (s.bypassOn()) return

        // Sent-reel lock: any swipe inside a DM-opened reel sends the user back
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && last == Sec.REELS && fromDm) {
            fromDm = false; performGlobalAction(GLOBAL_ACTION_BACK); return
        }

        val root = rootInActiveWindow ?: return
        val sec = detect(root)
        if (sec == Sec.OTHER) return                       // unknown UI -> fail open
        if (sec == Sec.REELS && last == Sec.DM) fromDm = true
        if (sec != Sec.REELS) fromDm = false
        last = sec
        if (blocked(sec)) block()
    }

    private fun blocked(sec: Sec): Boolean {
        val mode = s.effectiveMode; val limit = s.limitHit()
        return when (sec) {
            Sec.REELS -> if (fromDm) mode == Mode.MESSAGES || limit else s.blockReels || limit || mode != Mode.NONE
            Sec.EXPLORE -> s.blockExplore || limit || mode != Mode.NONE
            Sec.HOME -> limit || mode == Mode.MESSAGES || mode == Mode.REEL
            Sec.PROFILE -> limit || mode == Mode.MESSAGES || mode == Mode.REEL
            else -> false
        }
    }

    private fun detect(r: AccessibilityNodeInfo): Sec {
        fun nodes(id: String) = r.findAccessibilityNodeInfosByViewId("$ig:id/$id")
        if (dmIds.any { nodes(it).isNotEmpty() }) return Sec.DM
        if (reelIds.any { id -> nodes(id).any { it.isSelected || id.contains("pager") } }) return Sec.REELS
        return tabIds.entries.firstOrNull { (_, id) -> nodes(id).any { it.isSelected } }?.key ?: Sec.OTHER
    }

    private fun block() {
        val now = System.currentTimeMillis(); if (now - lastAct < 1500) return
        lastAct = now; fromDm = false
        performGlobalAction(GLOBAL_ACTION_BACK); show(BlockActivity::class.java)
    }

    private fun show(c: Class<*>) = startActivity(Intent(this, c).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
